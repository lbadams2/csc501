#ifndef _MATH_H_
#define _MATH_H_

//#define LN_10 2.302585093
#define RAND_MAX 077777

extern double expdev(double lambda);
extern volatile int acount;
extern volatile int bcount;
extern volatile int ccount;
#endif